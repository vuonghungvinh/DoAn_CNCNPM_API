<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DapAn extends Model
{
    protected $table = 'dapan';
}
