<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DeThiCauHoi extends Model
{
    protected $table = 'dethi_cauhoi';
}
