<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DeThiLichThi extends Model
{
    protected $table = 'dethi_lichthi';
}
