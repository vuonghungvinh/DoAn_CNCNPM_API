import { Component } from '@angular/core';

@Component({
  selector: 'exam-component',
  templateUrl: './exam.component.html',
  styleUrls: ['./exam.component.scss']
})

export class ExamComponent {

}
