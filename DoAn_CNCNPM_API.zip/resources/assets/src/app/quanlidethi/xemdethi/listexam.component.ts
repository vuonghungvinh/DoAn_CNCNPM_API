import { Component } from '@angular/core';

@Component({
  selector: 'exam-component',
  templateUrl: './listexam.component.html',
  styleUrls: ['./../../css/talbe.scss']
})

export class ListExamComponent {

}
