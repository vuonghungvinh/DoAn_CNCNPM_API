import { Component } from '@angular/core';

@Component({
  selector: 'score-component',
  templateUrl: './score.component.html',
  styleUrls: ['./score.component.scss']
})

export class ScoreComponent {

}
