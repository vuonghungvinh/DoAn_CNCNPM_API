import { Component } from '@angular/core';

@Component({
  selector: 'account-component',
  templateUrl: './taikhoan.component.html',
  styleUrls: ['./taikhoan.component.scss']
})

export class AccountComponent {

}
